
int add2(int x){
	return (x+y);
}

int main(){
    int i;
    int k=2;
    int j=2;
    i = add2(j,k);
    return i;
}

