int main() {
    int i = 1;
    if (i == 2) {
    }
    else {
    }
    return 0;
}
