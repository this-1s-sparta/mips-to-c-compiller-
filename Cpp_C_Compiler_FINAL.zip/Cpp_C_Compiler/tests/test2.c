int main() {
    int i = 1;
    while (i == 2) {
    }
    return 0;
}
